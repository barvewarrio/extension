这段代码是一个用于管理 WhatsApp 群组和号码采集的 Chrome 扩展程序的核心功能脚本。它主要处理以下几个方面的功能：

### 1. **激活管理**
   - **检查激活码是否过期**：通过 `i(t)` 函数检查激活码是否过期，如果过期则显示提示信息。
   - **激活插件**：通过 `_()` 函数处理用户输入的激活码，验证激活码的有效性，并根据验证结果更新插件状态。

### 2. **数据采集**
   - **采集 WhatsApp 群组和号码**：通过 `a()` 函数初始化数据导出功能，用户可以导出采集到的 WhatsApp 群组链接和号码。
   - **清空采集数据**：通过 `s()` 函数初始化数据清空功能，用户可以清空所有采集到的数据。
   - **管理采集任务状态**：通过 `e()` 函数管理后台采集任务的状态，用户可以暂停或继续采集任务。

### 3. **社交网络搜索**
   - **社交网络搜索功能**：通过 `l()` 函数初始化社交网络搜索功能，用户可以在不同的社交网络平台（如 Facebook、YouTube、Google 等）上搜索 WhatsApp 群组链接或号码。
   - **处理搜索请求**：根据用户选择的搜索目标和平台，生成相应的搜索 URL，并在新标签页中打开搜索结果。

### 4. **数据导出**
   - **导出采集数据**：通过 `m(t, o, a)` 函数将采集到的数据导出为 CSV 文件，用户可以下载采集到的数据。
   - **下载采集数据**：通过 `r()` 函数显示数据采集进度，并提供下载按钮，用户可以下载采集到的数据。

### 5. **国家区号和 Google 国家域名**
   - **获取国家区号**：通过 `u(t)` 函数获取指定国家的区号。
   - **获取 Google 国家域名**：通过 `n(t)` 函数获取指定国家的 Google 域名。

### 6. **其他功能**
   - **显示数据采集进度**：通过 `r()` 函数显示当前数据采集的进度，包括已采集的 WhatsApp 群组链接、号码、YouTube 视频等信息。
   - **处理消息**：通过 `chrome.runtime.onMessage.addListener` 监听来自其他脚本的消息，并根据消息内容更新界面或执行相应操作。

### 7. **MySQL 数据插入**
   - **installMysql(data)**：将采集到的数据插入到 MySQL 数据库中，数据包括群名称、群ID、群链接和原始记录。

### 8. **CSV 导出**
   - **m(t, o, a)**：将采集到的数据导出为 CSV 文件，用户可以下载该文件。

### 9. **界面更新**
   - **更新界面元素**：根据插件状态和用户操作，动态更新界面元素，如显示激活状态、采集进度、提示信息等。

### 10. **事件处理**
   - **处理用户点击事件**：通过 `$("#btn-export-whatsapp-group-member").click` 等事件处理函数，响应用户的点击操作，执行相应的功能。

### 11. **定时任务**
   - **定时更新数据采集进度**：通过 `setInterval(r, 3e3)` 定时调用 `r()` 函数，每 3 秒更新一次数据采集进度。

### 12. **消息监听**
   - **监听来自其他脚本的消息**：通过 `chrome.runtime.onMessage.addListener` 监听来自背景脚本或其他脚本的消息，并根据消息内容执行相应的操作。

### 13. **数据存储**
   - **存储和获取数据**：通过 `chrome.extension.getBackgroundPage().storage_get` 和 `chrome.extension.getBackgroundPage().storage_clear` 等函数，存储和获取采集到的数据。

### 14. **插件状态管理**
   - **管理插件状态**：通过 `chrome.extension.getBackgroundPage().plugin_set_expire` 和 `chrome.extension.getBackgroundPage().plugin_get_expire` 等函数，管理插件的激活状态和有效期。

### 15. **搜索功能**
   - **生成搜索 URL**：根据用户选择的搜索目标和平台，生成相应的搜索 URL，并在新标签页中打开搜索结果。

### 16. **数据导出**
   - **导出数据为 CSV**：通过 `m(t, o, a)` 函数将采集到的数据导出为 CSV 文件，用户可以下载该文件。

### 17. **MySQL 数据插入**
   - **将数据插入 MySQL 数据库**：通过 `installMysql(data)` 函数将采集到的数据插入到 MySQL 数据库中。

### 18. **界面更新**
   - **动态更新界面元素**：根据插件状态和用户操作，动态更新界面元素，如显示激活状态、采集进度、提示信息等。

### 19. **事件处理**
   - **处理用户点击事件**：通过 `$("#btn-export-whatsapp-group-member").click` 等事件处理函数，响应用户的点击操作，执行相应的功能。

### 20. **定时任务**
   - **定时更新数据采集进度**：通过 `setInterval(r, 3e3)` 定时调用 `r()` 函数，每 3 秒更新一次数据采集进度。

### 21. **消息监听**
   - **监听来自其他脚本的消息**：通过 `chrome.runtime.onMessage.addListener` 监听来自背景脚本或其他脚本的消息，并根据消息内容执行相应的操作。

### 22. **数据存储**
   - **存储和获取数据**：通过 `chrome.extension.getBackgroundPage().storage_get` 和 `chrome.extension.getBackgroundPage().storage_clear` 等函数，存储和获取采集到的数据。

### 23. **插件状态管理**
   - **管理插件状态**：通过 `chrome.extension.getBackgroundPage().plugin_set_expire` 和 `chrome.extension.getBackgroundPage().plugin_get_expire` 等函数，管理插件的激活状态和有效期。

### 24. **搜索功能**
   - **生成搜索 URL**：根据用户选择的搜索目标和平台，生成相应的搜索 URL，并在新标签页中打开搜索结果。

### 25. **数据导出**
   - **导出数据为 CSV**：通过 `m(t, o, a)` 函数将采集到的数据导出为 CSV 文件，用户可以下载该文件。

### 26. **MySQL 数据插入**
   - **将数据插入 MySQL 数据库**：通过 `installMysql(data)` 函数将采集到的数据插入到 MySQL 数据库中。

### 27. **界面更新**
   - **动态更新界面元素**：根据插件状态和用户操作，动态更新界面元素，如显示激活状态、采集进度、提示信息等。

### 28. **事件处理**
   - **处理用户点击事件**：通过 `$("#btn-export-whatsapp-group-member").click` 等事件处理函数，响应用户的点击操作，执行相应的功能。

### 29. **定时任务**
   - **定时更新数据采集进度**：通过 `setInterval(r, 3e3)` 定时调用 `r()` 函数，每 3 秒更新一次数据采集进度。

### 30. **消息监听**
   - **监听来自其他脚本的消息**：通过 `chrome.runtime.onMessage.addListener` 监听来自背景脚本或其他脚本的消息，并根据消息内容执行相应的操作。

### 31. **数据存储**
   - **存储和获取数据**：通过 `chrome.extension.getBackgroundPage().storage_get` 和 `chrome.extension.getBackgroundPage().storage_clear` 等函数，存储和获取采集到的数据。

### 32. **插件状态管理**
   - **管理插件状态**：通过 `chrome.extension.getBackgroundPage().plugin_set_expire` 和 `chrome.extension.getBackgroundPage().plugin_get_expire` 等函数，管理插件的激活状态和有效期。

### 33. **搜索功能**
   - **生成搜索 URL**：根据用户选择的搜索目标和平台，生成相应的搜索 URL，并在新标签页中打开搜索结果。

### 34. **数据导出**
   - **导出数据为 CSV**：通过 `m(t, o, a)` 函数将采集到的数据导出为 CSV 文件，用户可以下载该文件。

### 35. **MySQL 数据插入**
   - **将数据插入 MySQL 数据库**：通过 `installMysql(data)` 函数将采集到的数据插入到 MySQL 数据库中。

### 36. **界面更新**
   - **动态更新界面元素**：根据插件状态和用户操作，动态更新界面元素，如显示激活状态、采集进度、提示信息等。

### 37. **事件处理**
   - **处理用户点击事件**：通过 `$("#btn-export-whatsapp-group-member").click` 等事件处理函数，响应用户的点击操作，执行相应的功能。

### 38. **定时任务**
   - **定时更新数据采集进度**：通过 `setInterval(r, 3e3)` 定时调用 `r()` 函数，每 3 秒更新一次数据采集进度。

### 39. **消息监听**
   - **监听来自其他脚本的消息**：通过 `chrome.runtime.onMessage.addListener` 监听来自背景脚本或其他脚本的消息，并根据消息内容执行相应的操作。

### 40. **数据存储**
   - **存储和获取数据**：通过 `chrome.extension.getBackgroundPage().storage_get` 和 `chrome.extension.getBackgroundPage().storage_clear` 等函数，

function _(e = "") {
    return true;
}

function a() {
    chrome.tabs.getSelected(null, function (e) {
        e = e.url;
        (e && -1 != e.indexOf("facebook")) ||
            chrome.tabs.create({ url: "https://www.facebook.com" });
    });
}

function p(e, o, a = "asc") {
    return (
        "asc" == a &&
            e.sort(function (e, a) {
                return escape(e[o]).indexOf("%u") < 0
                    ? e[o] - a[o]
                    : e[o].localeCompare(a[o]);
            }),
        "desc" == a &&
            e.sort(function (e, a) {
                return escape(e[o]).indexOf("%u") < 0
                    ? a[o] - e[o]
                    : a[o].localeCompare(e[o]);
            }),
        e
    );
}

function e() {
    chrome.extension.getBackgroundPage().plugin_get_expire(function (e) {
        let a = e.expire;
        if (void 0 !== a) {
            console.log("expire_date"),
            console.log(a),
            (a = a.replace("T00:00:00.000Z", "")),
            $("#expire_date").html(a);
        }
    });
}

function o() {
    $("#extract-catalog-products-export-clean").click(function () {
        $("#message-info").html(
            '<span style="font-size: 12px;">提取需要花费时间，请保持界面不动,处理中...</span>',
        ),
        console.log("extract-catalog-products-url"),
        chrome.extension.getBackgroundPage().storage_get(function (o) {
            console.log("extract_catalog_products_export_clean"), console.log(o);
            var n,
                t = [],
                s = [];
            for (n in o)
                -1 != n.indexOf("shangjia_about_contact_and_basic_info_") &&
                ((o[n]._key_id = n), s.push(o[n]));
            var i,
                l = p(s, "num", "asc");
            console.log("shangjias_new_data"), console.log(l);
            for (let e = 0; e < l.length; e++) {
                var c = l[e],
                    r =
                        "shangjia_about_work_and_education_" +
                        l[e]._key_id.split("info_")[1];
                if (o.hasOwnProperty(r)) {
                    console.log("shangjia_about_work_and_education_key:" + r);
                    let e = o[r],
                        a = c._shangjia_followed;
                    console.log("_shangjia_followed:" + a),
                    (void 0 !== a && "" != a) ||
                        ((a = e._shangjia_followed),
                        console.log("_shangjia_followed 2:" + a));
                    r = {
                        id: c._shangjia_id,
                        "profile url": c._shangjia_about_contact_and_basic_info_link,
                        name: c._shangjia_name,
                        sex: c._shangjia_sex,
                        school: c._shangjia_school,
                        work: c._shangjia_work,
                        intro: c._shangjia_intro,
                        address: c._shangjia_address,
                        website: c._shangjia_website,
                        phone: c._shangjia_phone,
                        email: c._shangjia_email,
                        whatsapp: c._shangjia_whatsapp,
                        wechat: c._shangjia_wechat,
                        followed: a,
                        friends: c._shangjia_friends,
                        likes: c._shangjia_likes,
                        lives_in: c._shangjia_lives_in,
                        from: c._shangjia_from,
                        "company name": e._shangjia_company_name,
                        "company page": e._shangjia_company_page_link,
                        "company website": e._shangjia_company_website,
                        "company phone": e._shangjia_company_phone,
                        "company email": e._shangjia_company_email,
                        "company address": e._shangjia_company_address,
                        个人页是否请求完成: 2 == c._is_request ? "完成" : "未",
                        获取公司url是否完成: 2 == e._is_request ? "完成" : "未",
                        通过公司网址获取邮箱等是否完成:
                        2 == e._shangjia_company_is_request ? "完成" : "未",
                    };
                    t.push(r);
                }
            }
            console.log("export_datas"),
            console.log(t),
            u(t, "data-fb-export-" + Date.now(), "Sheet1"),
            $("#message-info").html("");
        });
    });
}

function n() {
    $("#extract-catalog-products-audience-export-clean").click(function () {
        $("#message-info").html(
            '<span style="font-size: 12px;">提取需要花费时间，请保持界面不动,处理中...</span>',
        ),
        console.log("extract_catalog_products_audience_export_clean"),
        chrome.extension.getBackgroundPage().storage_get(function (n) {
            console.log("extract_catalog_products_export_clean"), console.log(n);
            var a,
                t = [],
                o = [];
            for (a in n)
                -1 != a.indexOf("shangjia_about_contact_and_basic_info_") &&
                ((n[a]._key_id = a), o.push(n[a]));
            var s = p(o, "num", "asc");
            console.log("shangjias_new_data"), console.log(s);
            for (let e = 0; e < s.length; e++) {
                var i = s[e],
                    l =
                        "shangjia_about_work_and_education_" +
                        s[e]._key_id.split("info_")[1];
                if (n.hasOwnProperty(l)) {
                    console.log("shangjia_about_work_and_education_key:" + l), n[l];
                    (l = i._shangjia_id),
                        (l =
                            -1 != l.indexOf("&")
                                ? l.split("&")[0]
                                : -1 != l.indexOf("?")
                                    ? l.split("?")[0]
                                    : l);
                    let e = "",
                        a = "",
                        o = i._shangjia_name;
                    o &&
                        (2 == (c = (o = o.trim()).split(" ")).length &&
                            ((e = c[0]), (a = c[1])),
                        3 == c.length) &&
                        ((e = c[0] + " " + c[1]), (a = c[2]));
                    var c = {
                        uid: l,
                        fn: e,
                        ln: a,
                        email: i._shangjia_email,
                        phone: i._shangjia_phone,
                        已采集: 2 == i._is_request ? "是" : "未",
                    };
                    t.push(c);
                }
            }
            console.log("export_datas"),
                console.log(t),
                d(t, "data-fb-audience-export-" + Date.now(), "Sheet1"),
                $("#message-info").html("");
        });
    });
}

function t() {
    $("#extract-catalog-products-clean").click(function () {
        confirm("确认清空吗?") &&
            chrome.extension.getBackgroundPage().storage_clear();
    });
}

function s() {
    $("#extract-catalog-products-pause").click(function () {
        a();
        var e = chrome.extension.getBackgroundPage();
        e.pause_switch(function () {
            e.storage_get(function (e) {
                1 == e.pause
                    ? $("#extract-catalog-products-pause").text("采集已暂停,可点击开启")
                    : $("#extract-catalog-products-pause").text("采集已开启,可点击暂停");
            });
        });
    });
}

function i() {
    $("#btn-pause-list-switch").click(function () {
        a();
        var e = chrome.extension.getBackgroundPage();
        e.pause_list_switch(function () {
            e.storage_get(function (e) {
                1 == e.pause_list
                    ? $("#btn-pause-list-switch").text("前台采集已关闭,可点击开启")
                    : $("#btn-pause-list-switch").text("前台采集已开启,可点击暂停");
            });
        });
    });
}

function l() {
    var e = chrome.extension.getBackgroundPage();
    e.get_data_process(),
        e.data_process_get(function (e) {
            var a,
                o,
                e = e.data_process;
            void 0 !== e &&
                ((a = e.total_add_shangjia_num),
                (o = e.has_caiji_geren_num),
                (e = e.has_caiji_company_num),
                $("#data_process").html(
                    "已添加<span>" +
                        a +
                        "</span>个客户,已采集客户个人数据<span>" +
                        o +
                        "</span>个,已采集客户公司数据<span>" +
                        e +
                        "</span>个",
                ));
        });
}

function c() {
    $("#jihuo_btn").click(function () {
        var e = (e = $("#jihuo_text").val()).trim();
        if (($("#message-info").html(""), "" == e))
            $("#message-info").html('<span style="color:red;">请输入激活码</span>');
        else {
            let e = "2099-01-01",
                a = chrome.extension.getBackgroundPage();
            a.plugin_set_expire(e, function () {
                (e = e.replace("T00:00:00.000Z", "")),
                $("#expire_date").html(e),
                $(".jihuo").hide(),
                $("#message-account-info").html("");
            });
        }
    });
}

function r() {
    $("#custom-add-product-btn").click(function () {
        $(".custom-add-product-form-box").show();
    }),
        $("#custom-add-product-form-btn-submit").click(function () {
            let e = $(
                "form#custom-add-product-form #field-custom-product-links",
            ).val();
            if ("" == (e = e.trim()))
                return (
                    $("#message-info").html(
                        "<span style='color:red;'>链接不能为空！</span>",
                    ),
                    !1
                );
            var i = e.split(/[(\r\n)\r\n]+/),
                o = [];
            for (let a = 0; a < i.length; a++) {
                let e = i[a];
                "" != (e = e.trim()) && e.indexOf("profile.php");
            }
            if (0 < o.length) {
                let a = "";
                for (let e = 0; e < o.length; e++) a += o[e] + "<br />";
                return (
                    $("#message-info")
                        .html(
                            "<p style='color:red;'>以下链接不正确，请修正或者删除后提交</p>" +
                                a,
                        )
                        .css({ "max-height": "100px", "overflow-y": "auto" }),
                    !1
                );
            }
            let l = [];
            for (let s = 0; s < i.length; s++) {
                let e = i[s],
                    a = (e = e.trim()),
                    o = e.split("?"),
                    n = (2 <= o.length && (a = (a = o[1]).replace("id=", "")), ""),
                    t;
                t =
                    -1 == e.indexOf("?")
                        ? ((n = e + "?sk=about_contact_and_basic_info"),
                        e + "?sk=about_work_and_education")
                        : ((n = e + "&sk=about_contact_and_basic_info"),
                        e + "&sk=about_work_and_education");
                var c = {
                    _shangjia_id: a,
                    _shangjia_name: "",
                    _shangjia_jiaru_date: "",
                    _shangjia_work: "",
                    _shangjia_about_contact_and_basic_info_link: n,
                    _shangjia_about_work_and_education_link: t,
                    _shangjia_phone: "",
                    _shangjia_website: "",
                    _shangjia_email: "",
                    _shangjia_company_page_link: "",
                    _shangjia_company_is_request: 0,
                    _shangjia_company_name: "",
                    _shangjia_company_website: "",
                    _shangjia_company_phone: "",
                };
                l.push(c),
                50 <= l.length &&
                    (m({
                        action: "shangjia_items_update",
                        info: "",
                        shangjia_infos: l,
                    }),
                    (l = []));
            }
            m({ action: "shangjia_items_update", info: "", shangjia_infos: l }),
            window.alert("提交成功");
        });
}

function g() {
    IS_TIEPAI
        ? ($(".footer").remove(),
        $(".tiepai_footer").show(),
        $("body").css({ height: "290px" }))
        : ($(".footer").show(), $(".tiepai_footer").remove()),
        chrome.extension.getBackgroundPage().storage_get(function (e) {
            e.hasOwnProperty("pause_list") && 1 == e.pause_list
                ? $("#btn-pause-list-switch").text("前台采集已关闭,可点击开启")
                : $("#btn-pause-list-switch").text("前台采集已开启,可点击暂停"),
            e.hasOwnProperty("pause") && 1 == e.pause
                ? $("#extract-catalog-products-pause").text(
                    "后台采集已暂停,可点击开启",
                )
                : $("#extract-catalog-products-pause").text(
                    "后台采集已开启,可点击暂停",
                ),
            $("#extract-catalog-products-pause").show();
        });
}

function h(e) {
    var n = [];
    return (
        $.each(e[0], function (e, a) {
            var o = {};
            (o.headertext = e), (o.datatype = "string"), (o.datafield = e), n.push(o);
        }),
        n
    );
}

function u(e, a, o) {
    var n = XLSX.utils.book_new(),
        e = XLSX.utils.json_to_sheet(e);
    XLSX.utils.book_append_sheet(n, e, o), XLSX.writeFile(n, a + ".xlsx");
}

function d(e, a, o) {
    var n = XLSX.utils.book_new(),
        e = XLSX.utils.json_to_sheet(e);
    XLSX.utils.book_append_sheet(n, e, o), XLSX.writeFile(n, a + ".csv");
}

function m(e = {}) {
    console.log("message"),
        console.log(e),
        chrome.runtime.sendMessage(e, function (e) {
            console.log("收到来自background.js的响应: " + e);
        });
}

e(),
    o(),
    t(),
    s(),
    i(),
    l(),
    setInterval(l, 3e3),
    c(),
    r(),
    g(),
    chrome.runtime.onMessage.addListener((e, a, o) => {
        console.log("收到info:", e.info),
        console.log("收到action:", e.action),
        console.log("收到tbm_map_urls:", e.maijia_num),
        "update-shangjia-num" == e.action &&
            ((e = e.maijia_num), $(".catalog-products-num").html(e));
    }),
    document.getElementById("opnFacebook").addEventListener("click", function () {
        chrome.tabs.create({ url: "https://www.facebook.com" });
    });

    // 获取导入按钮
    const importToMysqlBtn = document.getElementById('importToMysqlBtn');
    
    // 添加点击事件处理
    if (importToMysqlBtn) {
        importToMysqlBtn.addEventListener('click', async () => {
            try {
                // 显示导入状态区域
                const importStatus = document.getElementById('import-status');
                const importStatusText = document.getElementById('import-status-text');
                const importSuccessCount = document.getElementById('import-success-count');
                const importFailedCount = document.getElementById('import-failed-count');
                const importProgress = document.getElementById('import-progress');
                importStatus.style.display = 'block';

                // 从存储中获取数据
                const storageData = await new Promise((resolve) => {
                    chrome.extension.getBackgroundPage().storage_get(resolve);
                });

                // 转换数据格式
                const dataToImport = Object.values(storageData)
                    .filter(item => item._shangjia_id) // 过滤有效数据
                    .map(item => {
                        // 转换性别字段
                        let sex = null;
                        if (item._shangjia_sex) {
                            switch (item._shangjia_sex.toLowerCase()) {
                                case '女性':
                                case 'female':
                                    sex = 'female';
                                    break;
                                case '男性':
                                case 'male':
                                    sex = 'male';
                                    break;
                                default:
                                    sex = 'other';
                            }
                        }

                        // 清理 friends 字段
                        let friends = 0;
                        if (item._shangjia_friends) {
                            const match = item._shangjia_friends.match(/\d+/);
                            if (match) {
                                friends = parseInt(match[0], 10);
                            }
                        }

                        // 清理 followed 字段
                        let followed = 0;
                        if (item._shangjia_followed) {
                            const match = item._shangjia_followed.match(/\d+/);
                            if (match) {
                                followed = parseInt(match[0], 10);
                            }
                        }

                        // 清理 likes 字段
                        let likes = 0;
                        if (item._shangjia_likes) {
                            const match = item._shangjia_likes.match(/\d+/);
                            if (match) {
                                likes = parseInt(match[0], 10);
                            }
                        }

                        return {
                            profile_url: item._shangjia_about_contact_and_basic_info_link,
                            name: item._shangjia_name,
                            sex: sex,
                            school: item._shangjia_school,
                            work: item._shangjia_work,
                            intro: item._shangjia_intro,
                            address: item._shangjia_address,
                            website: item._shangjia_website,
                            phone: item._shangjia_phone,
                            email: item._shangjia_email,
                            whatsapp: item._shangjia_whatsapp,
                            wechat: item._shangjia_wechat,
                            followed: followed,
                            friends: friends,
                            likes: likes,
                            lives_in: item._shangjia_lives_in,
                            from_location: item._shangjia_from,
                            company_name: item._shangjia_company_name,
                            company_page: item._shangjia_company_page_link,
                            company_website: item._shangjia_company_website,
                            company_phone: item._shangjia_company_phone,
                            company_email: item._shangjia_company_email,
                            company_address: item._shangjia_company_address,
                            personal_page_completed: item._is_request === 2 ? 1 : 0,
                            company_url_completed: item._shangjia_company_is_request === 2 ? 1 : 0,
                            country_code: "CN"
                        };
                    });

                // 数据验证
                if (!Array.isArray(dataToImport) || dataToImport.length === 0) {
                    alert('没有可导入的数据');
                    return;
                }

                // 显示加载状态
                importToMysqlBtn.disabled = true;
                importToMysqlBtn.textContent = '导入中...';

                // 初始化计数器
                let successCount = 0;
                let failedCount = 0;

                // 分批导入数据
                const batchSize = 50; // 每批导入 50 条数据
                const totalBatches = Math.ceil(dataToImport.length / batchSize);

                for (let i = 0; i < dataToImport.length; i += batchSize) {
                    const batch = dataToImport.slice(i, i + batchSize);

                    // 更新状态
                    const currentBatch = Math.ceil(i / batchSize) + 1;
                    importStatusText.textContent = `正在导入第 ${currentBatch} 批 / 共 ${totalBatches} 批`;
                    importProgress.value = (i / dataToImport.length) * 100;

                    try {
                        // 发送数据到服务器
                        const response = await fetch('http://localhost:3012/importFbMembers', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(batch),
                        });

                        const result = await response.json();

                        if (result.code === 200) {
                            successCount += result.result.length;
                            importSuccessCount.textContent = successCount;
                        } else {
                            failedCount += batch.length;
                            importFailedCount.textContent = failedCount;
                            console.error(`导入失败: ${result.message}`);
                        }
                    } catch (error) {
                        failedCount += batch.length;
                        importFailedCount.textContent = failedCount;
                        console.error('导入数据时出错:', error);
                    }
                }

                // 完成导入
                importStatusText.textContent = '导入完成';
                importProgress.value = 100;
                alert(`成功导入 ${successCount} 条数据，失败 ${failedCount} 条`);
            } catch (error) {
                console.error('导入数据时出错:', error);
                alert('导入数据时发生错误，请查看控制台');
            } finally {
                // 恢复按钮状态
                importToMysqlBtn.disabled = false;
                importToMysqlBtn.textContent = '导入到 MySQL';
            }
        });
    }
  
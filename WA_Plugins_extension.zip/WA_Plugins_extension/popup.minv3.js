/*
功能说明：
1. 管理WhatsApp群组和号码的采集
2. 处理YouTube视频采集
3. 提供数据导出功能
4. 管理插件激活状态
5. 提供社交网络搜索功能
6. 管理后台采集任务
*/

// Remove the activation check function
function i(t = "") {
  return true; // Always return true to bypass activation check
}

// 空函数，预留
function o() {}

// 获取国家区号
function u(t = "") {
  console.log("正在获取国家区号...");
  var o = {
    // 国家区号映射表
    "Afghanistan阿富汗": "+93",
    "Albania阿尔巴尼亚": "+355",
    "Algeria阿尔及利亚": "+213",
    "American Samoa美属萨摩亚": "+1",
    "Andorra安道尔": "+376",
    "Angola安哥拉": "+244",
    "Anguilla鳗鱼": "+1",
    "Antigua and Barbuda安提瓜和巴布达": "+1",
    "Argentina阿根廷": "+54",
    "Armenia亚美尼亚": "+374",
    "Aruba阿鲁巴": "+297",
    "Australia澳大利亚": "+61",
    "Austria奥地利": "+43",
    "Azerbaijan阿塞拜疆": "+994",
    "Bahamas巴哈马": "+1",
    "Bahrain巴林": "+973",
    "Bangladesh孟加拉国": "+880",
    "Barbados巴巴多斯": "+1",
    "Belarus白俄罗斯": "+375",
    "Belgium比利时": "+32",
    "Belize伯利兹": "+501",
    "Benin贝宁": "+229",
    "Bermuda百慕大": "+1",
    "Bhutan不丹": "+975",
    "Bolivia玻利维亚": "+591",
    "Bosnia and Herzegovina波斯尼亚和黑塞哥维那": "+387",
    "Botswana博茨瓦纳": "+267",
    "Brazil巴西": "+55",
    "British Indian Ocean Territory英属印度洋领地": "+246",
    "British Virgin Islands英属维尔京群岛": "+1",
    "Brunei文莱": "+673",
    "Bulgaria保加利亚": "+359",
    "Burkina Faso布基纳法索": "+226",
    "Burundi布隆迪": "+257",
    "Cambodia柬埔寨": "+855",
    "Cameroon喀麦隆": "+237",
    "Canada加拿大": "+1",
    "Cape Verde佛得角": "+238",
    "Caribbean Netherlands加勒比海荷兰": "+599",
    "Cayman Islands开曼群岛": "+1",
    "Central African Republic中非共和国": "+236",
    "Chad乍得": "+235",
    "Chile智利": "+56",
    "China中国": "+86",
    "Christmas Island圣诞岛": "+61",
    "CocosKeeling Islands科科斯（基林）群岛": "+61",
    "Colombia哥伦比亚": "+57",
    "Comoros科摩罗": "+269",
    "CongoDRC刚果民主共和国": "+243",
    "CongoRepublic刚果共和国": "+242",
    "Cook Islands库克群岛": "+682",
    "Costa Rica哥斯达黎加": "+506",
    "Côte d'Ivoire科特迪瓦": "+225",
    "Croatia克罗地亚": "+385",
    "Cuba古巴": "+53",
    "Curaçao库拉索": "+599",
    "Cyprus塞浦路斯": "+357",
    "Czech Republic捷克共和国": "+420",
    "Denmark丹麦": "+45",
    "Djibouti吉布提": "+253",
    "Dominica多米尼克": "+1",
    "Dominican Republic多米尼加共和国": "+1",
    "Ecuador厄瓜多尔": "+593",
    "Egypt埃及": "+20",
    "El Salvador萨尔瓦多": "+503",
    "Equatorial Guinea赤道几内亚": "+240",
    "Eritrea厄立特里亚": "+291",
    "EstoniaEesti爱沙尼亚（东）": "+372",
    "Ethiopia埃塞俄比亚": "+251",
    "Falkland Islands福克兰群岛": "+500",
    "Faroe IslandsFøroyar法罗群岛": "+298",
    "Fiji斐济": "+679",
    "FinlandSuomi芬兰": "+358",
    "France法国": "+33",
    "French Guiana法属圭亚那": "+594",
    "French Polynesia法属波利尼西亚": "+689",
    "Gabon加蓬": "+241",
    "Gambia冈比亚": "+220",
    "Georgia格鲁吉亚": "+995",
    "Germany德国": "+49",
    "Ghana加纳": "+233",
    "Gibraltar直布罗陀": "+350",
    "Greece希腊": "+30",
    "Greenland格陵兰": "+299",
    "Grenada格林纳达岛": "+1",
    "Guadeloupe瓜德罗普岛": "+590",
    "Guam关岛": "+1",
    "Guatemala危地马拉": "+502",
    "Guernsey根西岛": "+44",
    "Guinea几内亚": "+224",
    "Guinea - Bissau几内亚 - 比绍": "+245",
    "Guyana圭亚那": "+592",
    "Haiti海地": "+509",
    "Honduras洪都拉斯": "+504",
    "Hong Kong中国香港": "+852",
    "Hungary匈牙利": "+36",
    "Iceland冰岛": "+354",
    "India印度": "+91",
    "Indonesia印度尼西亚": "+62",
    "Iran伊朗": "+98",
    "Iraq伊拉克": "+964",
    "Ireland爱尔兰": "+353",
    "Isle of Man马恩岛": "+44",
    "Israel以色列": "+972",
    "Italy意大利": "+39",
    "Jamaica牙买加": "+1",
    "Japan日本": "+81",
    "Jersey泽西": "+44",
    "Jordan约旦": "+962",
    "Kazakhstan哈萨克斯坦": "+7",
    "Kenya肯尼亚": "+254",
    "Kiribati基里巴斯": "+686",
    "Kosovo科索沃": "+383",
    "Kuwait科威特": "+965",
    "Kyrgyzstan吉尔吉斯斯坦": "+996",
    "Laos老挝": "+856",
    "Latvia拉脱维亚": "+371",
    "Lebanon黎巴嫩": "+961",
    "Lesotho莱索托": "+266",
    "Liberia利比里亚": "+231",
    "Libya利比亚": "+218",
    "Liechtenstein列支敦士登": "+423",
    "Lithuania立陶宛": "+370",
    "Luxembourg卢森堡": "+352",
    "Macau中国澳門": "+853",
    "Macedonia马其顿": "+389",
    "Madagascar马达加斯加": "+261",
    "Malawi马拉维": "+265",
    "Malaysia马来西亚": "+60",
    "Maldives马尔代夫": "+960",
    "Mali马里": "+223",
    "Malta马耳他": "+356",
    "Marshall Islands马绍尔群岛": "+692",
    "Martinique马提尼克": "+596",
    "Mauritania毛里塔尼亚": "+222",
    "Mauritius毛里求斯": "+230",
    "Mayotte马约特岛": "+262",
    "Mexico墨西哥": "+521",
    "Micronesia密克罗尼西亚": "+691",
    "Moldova摩尔多瓦": "+373",
    "Monaco摩纳哥": "+377",
    "Mongolia蒙古": "+976",
    "Montenegro黑山": "+382",
    "Montserrat蒙特塞拉特": "+1",
    "Morocco摩洛哥": "+212",
    "Mozambique莫桑比克": "+258",
    "Myanmar缅甸": "+95",
    "Namibia纳米比亚": "+264",
    "Nauru瑙鲁": "+674",
    "Nepal尼泊尔": "+977",
    "Netherlands荷兰": "+31",
    "New Caledonia新喀里多尼亚": "+687",
    "New Zealand新西兰": "+64",
    "Nicaragua尼加拉瓜": "+505",
    "Niger尼日尔": "+227",
    "Nigeria尼日利亚": "+234",
    "Niue纽埃": "+683",
    "Norfolk Island诺福克岛": "+672",
    "North Korea朝鲜": "+850",
    "Northern Mariana Islands北马里亚纳群岛": "+1",
    "Norway挪威": "+47",
    "Oman阿曼": "+968",
    "Pakistan巴基斯坦": "+92",
    "Palau帕劳": "+680",
    "Palestine巴勒斯坦": "+970",
    "Panama巴拿马": "+507",
    "Papua New Guinea巴布亚新几内亚": "+675",
    "Paraguay巴拉圭": "+595",
    "Peru秘鲁": "+51",
    "Philippines菲律宾": "+63",
    "Poland波兰": "+48",
    "Portugal葡萄牙": "+351",
    "Puerto Rico波多黎各": "+1",
    "Qatar卡塔尔": "+974",
    "Réunion会议": "+262",
    "Romania罗马尼亚": "+40",
    "Russia俄罗斯": "+7",
    "Rwanda卢旺达": "+250",
    "Saint Barthélemy圣巴塞洛缪": "+590",
    "Saint Helena圣赫勒拿": "+290",
    "Saint Kitts and Nevis圣基茨和尼维斯": "+1",
    "Saint Lucia圣卢西亚": "+1",
    "Saint Martin圣马丁": "+590",
    "Saint Pierre and Miquelon圣彼得和密克隆": "+508",
    "Saint Vincent and the Grenadines圣文森特和格林纳丁斯": "+1",
    "Samoa萨摩亚": "+685",
    "San Marino圣马力诺": "+378",
    "São Tomé and Príncipe圣多美和普林西比": "+239",
    "Saudi Arabia沙特阿拉伯": "+966",
    "Senegal塞内加尔": "+221",
    "Serbia塞尔维亚": "+381",
    "Seychelles塞舌尔": "+248",
    "Sierra Leone塞拉利昂": "+232",
    "Singapore新加坡": "+65",
    "Sint Maarten圣马丁岛": "+1",
    "Slovakia斯洛伐克": "+421",
    "Slovenia斯洛文尼亚": "+386",
    "Solomon Islands所罗门群岛": "+677",
    "Somalia索马里": "+252",
    "South Africa南非": "+27",
    "South Korea韩国": "+82",
    "South Sudan南苏丹": "+211",
    "Spain西班牙": "+34",
    "Sri Lanka斯里兰卡": "+94",
    "Sudan苏丹": "+249",
    "Suriname苏里南": "+597",
    "Svalbard and Jan Mayen斯瓦尔巴和扬马延": "+47",
    "Swaziland斯威士兰": "+268",
    "Sweden瑞典": "+46",
    "Switzerland瑞士": "+41",
    "Syria叙利亚": "+963",
    "Taiwan中国台湾": "+886",
    "Tajikistan塔吉克斯坦": "+992",
    "Tanzania坦桑尼亚": "+255",
    "Thailand泰国": "+66",
    "Timor-Leste帝汶-东": "+670",
    "Togo多哥": "+228",
    "Tokelau托克劳": "+690",
    "Tonga汤加": "+676",
    "Trinidad and Tobago特立尼达和多巴哥": "+1",
    "Tunisia突尼斯": "+216",
    "Turkey土耳其": "+90",
    "Turkmenistan土库曼斯坦": "+993",
    "Turks and Caicos Islands特克斯和凯科斯群岛": "+1",
    "Tuvalu图瓦卢": "+688",
    "U.S.Virgin Islands美属维尔京群岛": "+1",
    "Uganda乌干达": "+256",
    "Ukraine乌克兰": "+380",
    "United Arab Emirates阿拉伯联合酋长国": "+971",
    "United Kingdom英国": "+44",
    "United States美国": "+1",
    "Uruguay乌拉圭": "+598",
    "Uzbekistan乌兹别克斯坦": "+998",
    "Vanuatu瓦努阿图": "+678",
    "Vatican City梵蒂冈城": "+39",
    "Venezuela委内瑞拉": "+58",
    "Vietnam越南": "+84",
    "Wallis and Futuna瓦利斯和富图纳": "+681",
    "Western Sahara西撒哈拉": "+212",
    "Yemen也门": "+967",
    "Zambia赞比亚": "+260",
    "Zimbabwe津巴布韦": "+263",
    "Åland Islands奥兰群岛": "+358",
  };
  return o.hasOwnProperty(t) ? o[t] : "+86";
}

// Remove the activation status check function
function t() {
  console.log("跳过插件激活状态检查...");
  $(".jihuo").hide(); // Hide activation related UI
  $("#expire_date").html("<span style='color:green;'>已激活</span>");
}

// 导出采集数据
function a() {
  console.log("初始化数据导出功能...");
  $("#extract-catalog-products-export-clean").click(function () {
    $("#message-info").html(
      '<span style="font-size: 12px;">提取需要花费时间，请保持界面不动,处理中...</span>'
    ),
    chrome.extension.getBackgroundPage().storage_get(function (s) {
      console.log("extract_catalog_products_export_clean"), console.log(s);
      let t = !1,
        o = s.expire;
      (void 0 !== o &&
        (console.log("expire_date"),
        console.log(o),
        (o = o.replace("T00:00:00.000Z", "")),
        $("#expire_date").html(o),
        !i(o))) ||
        ($(".jihuo").show(),
        $("#expire_date").html(
          "<span style='color:red;'>已过期或未激活</span>"
        ),
        IS_TIEPAI
          ? $("#message-info").html(
              "<span style='color:red;'>已过期或未激活，联系客服！</span>"
            )
          : $("#message-info").html(
              "<span style='color:red;'>已过期或未激活，</span><a href='https://www.gycharm.com/user/order-plugin?plugin=vip_ws_1nian' target='_blank'>续费或者购买后，</a> <span style='color:red;'>在下面输入框激活！</span>"
            ),
        (t = !0));
      var a,
        e,
        n,
        l,
        r,
        _ = [];
      for (a in s)
        -1 != a.indexOf("shangjia_whatsapp_group_info_") &&
          ((e = {
            群组链接或者号码: (e = s[a])._shangjia_id,
            来源: e._shangjia_url,
          }),
          _.push(e));
      for (n in s)
        if (
          -1 != n.indexOf("youtube_shangjia_about_contact_and_basic_info_")
        ) {
          let t,
            o = s[n],
            a = o._hongren_whatsapp_group;
          "" != (a = a.trim()) &&
            ((t = {
              群组链接或者号码: a,
              来源: o._shangjia_about_contact_and_basic_info_link,
            }),
            _.push(t));
        }
      for (l in s)
        if (-1 != l.indexOf("shangjia_whatsapp_num_info_")) {
          let t,
            o = s[l],
            a = o._num;
          "" != (a = a.trim()) &&
            ((t = { 群组链接或者号码: a, 来源: o._url }), _.push(t));
        }
      for (r in s)
        if (
          -1 != r.indexOf("youtube_shangjia_about_contact_and_basic_info_")
        ) {
          let t,
            o = s[r],
            a = o._hongren_whatsapp;
          (a = a.trim()) &&
            ((t = {
              群组链接或者号码: o._hongren_whatsapp,
              来源: o._shangjia_about_contact_and_basic_info_link,
            }),
            _.push(t));
        }
      if ((console.log(_), t)) {
        let t = _;
        5 < _.length &&
          (t = _.slice(0, 5)).push({
            群组链接或者号码:
              "提醒：开通正式版，导出更多记录，https://www.gycharm.com/",
            来源: "",
          }),
          m(t, "data-fb-export-" + Date.now(), "Sheet1"),
          $("#message-info").html(
            "<span style='color:red;'>提醒：试用版只能导出前5条数据！</span>"
          ),
          alert("提醒：试用版只能导出前5条数据！");
      } else m(_, "gycharm-ws-export-" + Date.now(), "Sheet1"), $("#message-info").html("");
    });
  });
}

// 清空采集数据
function s() {
  console.log("初始化数据清空功能...");
  $("#extract-catalog-products-clean").click(function () {
    confirm("确定清空吗？") &&
      chrome.extension.getBackgroundPage().storage_clear();
  });
}

// 管理采集任务状态
function e() {
  console.log("初始化采集任务管理功能...");
  $("#extract-catalog-products-pause").click(function () {
    var t = chrome.extension.getBackgroundPage();
    t.pause_switch(function () {
      t.storage_get(function (t) {
        1 == t.pause
          ? $("#extract-catalog-products-pause").text(
              "youtube后台采集已暂停,可点击开启"
            )
          : $("#extract-catalog-products-pause").text(
              "youtube后台采集已开启,可点击暂停"
            );
      });
    });
  });
}

// 获取Google国家域名
function n(t = "countryUS") {
  console.log("正在获取Google国家域名...");
  var o = {
    countryUS: "https://www.google.com/",
    countryCA: "https://www.google.ca/",
    countryCD: "https://www.google.cd/",
    countryCG: "https://www.google.cg/",
    countryCH: "https://www.google.ch/",
    countryCI: "https://www.google.ci/",
    countryCK: "https://www.google.co.ck/",
    countryCL: "https://www.google.cl/",
    countryCO: "https://www.google.com.co/",
    countryCR: "https://www.google.co.cr/",
    countryCU: "https://www.google.com.cu/",
    countryCZ: "https://www.google.cz/",
    countryDE: "https://www.google.de/",
    countryDJ: "https://www.google.dj/",
    countryDK: "https://www.google.dk/",
    countryDM: "https://www.google.dm/",
    countryDO: "https://www.google.com.do/",
    countryEC: "https://www.google.com.ec/",
    countryEE: "https://www.google.ee/",
    countryEG: "https://www.google.com.eg/",
    countryES: "https://www.google.es/",
    countryET: "https://www.google.com.et/",
    countryFJ: "https://www.google.com.fj/",
    countryFM: "https://www.google.fm/",
    countryFR: "https://www.google.fr/",
    countryGE: "https://www.google.ge/",
    countryGI: "https://www.google.com.gi/",
    countryGL: "https://www.google.gl/",
    countryGM: "https://www.google.gm/",
    countryGP: "https://www.google.gp/",
    countryGR: "https://www.google.gr/",
    countryGT: "https://www.google.com.gt/",
    countryGY: "https://www.google.gy/",
    countryHK: "https://www.google.com.hk/",
    countryHR: "https://www.google.hr/",
    countryHT: "https://www.google.ht/",
    countryHU: "https://www.google.hu/",
    countryID: "https://www.google.co.id/",
    countryIE: "https://www.google.ie/",
    countryIL: "https://www.google.co.il/",
    countryIN: "https://www.google.co.in/",
    countryIS: "https://www.google.is/",
    countryIT: "https://www.google.it/",
    countryJM: "https://www.google.je/",
    countryJO: "https://www.google.jo/",
    countryJP: "https://www.google.co.jp/",
    countryKE: "https://www.google.co.ke/",
    countryKH: "https://www.google.com.kh/",
    countryKI: "https://www.google.ki/",
    countryKG: "https://www.google.kg/",
    countryKR: "https://www.google.co.kr/",
    countryKZ: "https://www.google.kz/",
    countryLA: "https://www.google.la/",
    countryLI: "https://www.google.li/",
    countryLK: "https://www.google.lk/",
    countryLS: "https://www.google.co.ls/",
    countryLT: "https://www.google.lt/",
    countryLU: "https://www.google.lu/",
    countryLV: "https://www.google.lv/",
    countryLY: "https://www.google.com.ly/",
    countryMA: "https://www.google.co.ma/",
    countryMD: "https://www.google.md/",
    countryMN: "https://www.google.mn/",
    countryMS: "https://www.google.ms/",
    countryMT: "https://www.google.com.mt/",
    countryMU: "https://www.google.mu/",
    countryMV: "https://www.google.mv/",
    countryMW: "https://www.google.mw/",
    countryMX: "https://www.google.com.mx/",
    countryNA: "https://www.google.com.na/",
    countryNF: "https://www.google.com.nf/",
    countryNG: "https://www.google.com.ng/",
    countryNI: "https://www.google.com.ni/",
    countryNL: "https://www.google.nl/",
    countryNO: "https://www.google.no/",
    countryNP: "https://www.google.com.np/",
    countryNR: "https://www.google.nr/",
    countryNU: "https://www.google.nu/",
    countryNZ: "https://www.google.co.nz/",
    countryOM: "https://www.google.com.om/",
    countryPA: "https://www.google.com.pa/",
    countryPE: "https://www.google.com.pe/",
    countryPH: "https://www.google.com.ph/",
    countryPK: "https://www.google.com.pk/",
    countryPL: "https://www.google.pl/",
    countryPN: "https://www.google.pn/",
    countryPR: "https://www.google.com.pr/",
    countryPT: "https://www.google.pt/",
    countryPY: "https://www.google.com.py/",
    countryQA: "https://www.google.com.qa/",
    countryRO: "https://www.google.ro/",
    countryRU: "https://www.google.ru/",
    countryRW: "https://www.google.rw/",
    countrySA: "https://www.google.com.sa/",
    countrySB: "https://www.google.com.sb/",
    countrySC: "https://www.google.sc/",
    countrySE: "https://www.google.se/",
    countrySG: "https://www.google.com.sg/",
    countrySH: "https://www.google.sh/",
    countrySI: "https://www.google.si/",
    countrySK: "https://www.google.sk/",
    countrySN: "https://www.google.sn/",
    countrySM: "https://www.google.sm/",
    countryST: "https://www.google.st/",
    countrySV: "https://www.google.com.sv/",
    countryTH: "https://www.google.co.th/",
    countryTJ: "https://www.google.com.tj/",
    countryTK: "https://www.google.tk/",
    countryTM: "https://www.google.tm/",
    countryTO: "https://www.google.to/",
    countryTR: "https://www.google.com.tr/",
    countryTT: "https://www.google.tt/",
    countryTW: "https://www.google.com.tw/",
    countryUA: "https://www.google.com.ua/",
    countryUG: "https://www.google.co.ug/",
    countryGB: "https://www.google.co.uk/",
    countryUY: "https://www.google.com.uy/",
    countryUZ: "https://www.google.co.uz/",
    countryVC: "https://www.google.com.vc/",
    countryVE: "https://www.google.co.ve/",
    countryVG: "https://www.google.vg/",
    countryVI: "https://www.google.co.vi/",
    countryVN: "https://www.google.com.vn/",
    countryVU: "https://www.google.vu/",
    countryWS: "https://www.google.ws/",
    countryZA: "https://www.google.co.za/",
    countryZM: "https://www.google.co.zm/",
    countryZW: "https://www.google.co.zw/",
  };
  return o.hasOwnProperty(t) ? o[t] : "https://www.google.com/";
}

// 处理社交网络搜索
function l() {
  console.log("初始化社交网络搜索功能...");
  $(".form-sns #form_sns_submit").click(function () {
    console.log("用户提交了社交网络搜索请求");
    var _ = chrome.extension.getBackgroundPage(),
      t = { as_q: a, sns_target_val: t, sns_plateform_val: s, cr_val: l };
    _.google_sns_keyword_set(t, function () {
      chrome.tabs.create({ url: r });
    });
  });
}

// 显示数据采集进度
function r() {
  console.log("正在获取数据采集进度...");
  var t = chrome.extension.getBackgroundPage();
  t.get_data_process(),
    t.data_process_get(function (t) {
      var o,
        a,
        s,
        t = t.data_process;
      void 0 !== t &&
        (t.total_add_shangjia_num,
        t.has_caiji_geren_num,
        t.has_caiji_company_num,
        (o = t.total_whatsapp_group),
        (a = t.total_whatsapp_num),
        (s = t.youtube_total_add_num),
        (t = t.youtube_has_caiji_num),
        $("#data_process").html(
          "已采集<span>" +
            o +
            "</span>个whatsapp群组链接<span>，已采集<span>" +
            a +
            "</span>号码<br />Youtube已添加<span>" +
            s +
            "</span>个视频，已采集<span>" +
            t +
            "</span>个"
        ));
    });
}

// Remove the activation function
function _() {
  console.log("跳过激活功能...");
  $("#jihuo_btn").click(function() {
    $("#message-info").html("<span style='color:green;'>无需激活</span>");
  });
}

function g() {
  $("#sns_target").change(function () {
    var t = $(this).val(),
      o = $("#sns_plateform").val();
    "target_group" == t
      ? ($("#country_name_box").hide(),
        "sns_youtube" != o && "sns_facebook" != o
          ? $("#country_name_box2").show()
          : $("#country_name_box2").hide())
      : ($("#country_name_box2").hide(), $("#country_name_box").show());
  });
}

function c() {
  $("#sns_plateform").change(function () {
    var t = $(this).val();
    "target_group" == $("#sns_target").val()
      ? ($("#country_name_box").hide(),
        "sns_youtube" != t && "sns_facebook" != t
          ? $("#country_name_box2").show()
          : $("#country_name_box2").hide())
      : ($("#country_name_box2").hide(), $("#country_name_box").show());
  });
}

function w() {
  IS_TIEPAI
    ? ($(".footer").remove(),
      $(".tiepai_footer").show(),
      $("body").css({ height: "210px" }))
    : ($(".footer").show(), $(".tiepai_footer").remove());
  var t = chrome.extension.getBackgroundPage();
  t.storage_get(function (t) {
    t.hasOwnProperty("pause") && 1 == t.pause
      ? $("#extract-catalog-products-pause").text(
          "youtube后台采集已暂停,可点击开启"
        )
      : $("#extract-catalog-products-pause").text(
          "youtube后台采集已开启,可点击暂停"
        ),
      $("#extract-catalog-products-pause").show();
  }),
    t.google_sns_keyword_get(function (t) {
      var o,
        a,
        s,
        t = t.google_sns_keywords;
      void 0 !== t &&
        ((o = t.as_q),
        (a = t.sns_target_val),
        (s = t.sns_plateform_val),
        (t = t.cr_val),
        $(".form-sns #as_q").val(o),
        $(".form-sns #sns_target").val(a),
        $(".form-sns #sns_plateform").val(s),
        $(".form-sns #cr").val(t),
        "target_group" == a
          ? ($("#country_name_box").hide(),
            "sns_youtube" != s && "sns_facebook" != s
              ? $("#country_name_box2").show()
              : $("#country_name_box2").hide())
          : ($("#country_name_box2").hide(), $("#country_name_box").show()));
    });
}

function p() {
  $("#btn-export-whatsapp-group-member").click(function () {
    $("#message-info").html(
      '<span style="font-size: 12px;">提取需要花费时间，请保持界面不动,处理中...</span>'
    ),
      console.log("export-whatsapp-group-member"),
      chrome.tabs.query({ active: !0, currentWindow: !0 }, (t) => {
        chrome.tabs.sendMessage(
          t[0].id,
          { action: "export_whatsapp_group_member", info: "" },
          (t) => {
            console.log("popup=>content export_whatsapp_group_member"),
              console.log(t);
          }
        );
      });
  });
}

t(),
  a(),
  s(),
  e(),
  l(),
  r(),
  setInterval(r, 3e3),
  _(),
  g(),
  c(),
  w(),
  p(),
  chrome.runtime.onMessage.addListener((t, o, a) => {
    var s;
    console.log("收到消息:", t),
      "update-shangjia-num" == t.action &&
        ((s = t.maijia_num), $(".catalog-products-num").html(s)),
      "background-tips" == t.action &&
        $("#message-info").html("<div style='color:red'>" + t.info + "</div>"),
      a("popup已经收到");
  });

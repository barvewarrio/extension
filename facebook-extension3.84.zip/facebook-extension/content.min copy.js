function o() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (n) => {
      console.log("can_list_caiji 答复", n);
      var t,
        n = JSON.parse(n);
      console.log(n.state),
        0 == n.state
          ? (console.log("shangjia_group_caiji dd"),
            (n = window.location.href) &&
              -1 != n.indexOf("groups") &&
              ((t = []),
              $("div[role='list'] div[role='listitem']").each(function () {
                console.log("listitem");
                var n,
                  i,
                  o,
                  a,
                  e = $(this).find("a[role='link']:eq(1)").text(),
                  s = $(this).find("a[role='link']:eq(1)").attr("href");
                s &&
                  ((n =
                    "https://www.facebook.com/profile.php?id=" +
                    (s = (s = s.split("/"))[s.length - 2]) +
                    "&sk=about_work_and_education"),
                  (i =
                    "https://www.facebook.com/profile.php?id=" +
                    s +
                    "&sk=about_contact_and_basic_info"),
                  (o = $(this).find(".xu06os2 .x193iq5w .x193iq5w").text()),
                  (a = $(this).find(".xu06os2 .x193iq5w.x1pg5gke").text()),
                  t.push({
                    _shangjia_id: s,
                    _shangjia_name: e,
                    _shangjia_jiaru_date: o,
                    _shangjia_work: a,
                    _shangjia_about_contact_and_basic_info_link: i,
                    _shangjia_about_work_and_education_link: n,
                    _shangjia_phone: "",
                    _shangjia_website: "",
                    _shangjia_email: "",
                    _shangjia_company_page_link: "",
                    _shangjia_company_is_request: 0,
                    _shangjia_company_name: "",
                    _shangjia_company_website: "",
                    _shangjia_company_phone: "",
                  }));
              }),
              0 < t.length) &&
              ((n = {
                action: "shangjia_items_update",
                info: "",
                shangjia_infos: t,
              }),
              console.log("message"),
              console.log(n),
              chrome.runtime.sendMessage(n, (n) => {
                console.log("答复", n), x("添加完成！");
              })))
          : x("请点击右上角插件图标，开启前台采集！");
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function a() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (n) => {
      console.log("can_list_caiji 答复", n);
      var i,
        o,
        n = JSON.parse(n);
      console.log(n.state),
        0 == n.state &&
          (n = window.location.href) &&
          -1 != n.indexOf("groups") &&
          ((n = $("h1.x1heor9g span.x193iq5w a.x1i10hfl").text()),
          (o = ""),
          (o = (i = $("h1.x1heor9g span.x193iq5w a.x1i10hfl").attr("href"))
            ? i
                .replace("https://www.facebook.com/", "")
                .replace("groups", "")
                .replaceAll("/", "")
            : "")) &&
          ((o = {
            action: "shangjia_group_info_send",
            info: "",
            group_info: { group_id: o, group_name: n, group_url: i },
          }),
          console.log(o),
          f(o));
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function e() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    let i = window.location.href;
    chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (n) => {
      console.log("can_list_caiji 答复", n);
      var s,
        n = JSON.parse(n);
      console.log(n.state),
        0 == n.state
          ? (console.log("shangjia_friends_caiji"),
            (-1 == i.indexOf("friends") &&
              -1 == i.indexOf("followers") &&
              -1 == i.indexOf("following")) ||
              ((s = []),
              $(".x1a02dak.x1qughib .x1swvt13.x1gefphp").each(function () {
                let n,
                  i = $(this).find("a.x1i10hfl").text(),
                  o = $(this).find("a.x1i10hfl").attr("href"),
                  a = "",
                  e;
                o &&
                  ((e =
                    -1 != o.indexOf("?")
                      ? ((a = o + "&sk=about_work_and_education"),
                        o + "&sk=about_contact_and_basic_info")
                      : ((a = o + "?sk=about_work_and_education"),
                        o + "?sk=about_contact_and_basic_info")),
                  (n = {
                    _shangjia_id: o
                      .replace("https://www.facebook.com/", "")
                      .replace("profile.php?id=", ""),
                    _shangjia_name: i,
                    _shangjia_jiaru_date: "",
                    _shangjia_work: $(this).find(".x1gslohp .xdj266r").text(),
                    _shangjia_about_contact_and_basic_info_link: e,
                    _shangjia_about_work_and_education_link: a,
                    _shangjia_phone: "",
                    _shangjia_website: "",
                    _shangjia_email: "",
                    _shangjia_company_page_link: "",
                    _shangjia_company_is_request: 0,
                    _shangjia_company_name: "",
                    _shangjia_company_website: "",
                    _shangjia_company_phone: "",
                  }),
                  s.push(n));
              }),
              0 < s.length &&
                ((n = {
                  action: "shangjia_items_update",
                  info: "",
                  shangjia_infos: s,
                }),
                console.log("message"),
                console.log(n),
                chrome.runtime.sendMessage(n, (n) => {
                  console.log("答复", n), x("添加完成！");
                }))))
          : x("请点击右上角插件图标，开启前台采集！");
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function s() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    window.location.href,
      chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (o) => {
        console.log("can_list_caiji 答复", o);
        o = JSON.parse(o);
        if ((console.log(o.state), 0 == o.state)) {
          var o = $("h1.x1heor9g.x1qlqyl8").text(),
            a = $(".x9f619 .x193iq5w a.x1s688f").attr("href");
          if (
            (console.log("shangjia_friends_send group_name:" + o),
            console.log("shangjia_friends_send group url:" + a),
            -1 == a.indexOf("groups") &&
              (-1 != a.indexOf("friends") ||
                -1 != a.indexOf("followers") ||
                -1 != a.indexOf("following")))
          ) {
            let n = a.replace("https://www.facebook.com/profile.php?id=", ""),
              i = {
                action: "shangjia_group_info_send",
                info: "",
                group_info: {
                  group_id: (n = n
                    .replace("&sk=friends", "")
                    .replace("&sk=followers", "")
                    .replace("&sk=following", "")),
                  group_name: o,
                  group_url: a,
                },
              };
            console.log(i), f(i);
          }
        }
      });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function t() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (n) => {
      console.log("can_list_caiji 答复", n);
      var s,
        n = JSON.parse(n);
      console.log(n.state),
        0 == n.state
          ? (n = window.location.href) &&
            -1 != n.indexOf("search/people") &&
            (console.log("shangjia_search_people_caiji"),
            (s = []),
            $(".x1t2pt76 .x1xwk8fm .x1yztbdb").each(function () {
              console.log("shangjia_search_people_caiji a1");
              let n,
                i = $(this).find(".x1ja2u2z a.x1i10hfl").text(),
                o = $(this).find(".x1ja2u2z a.x1i10hfl").attr("href"),
                a = "",
                e;
              o &&
                ((e =
                  -1 != o.indexOf("?")
                    ? ((a = o + "&sk=about_work_and_education"),
                      o + "&sk=about_contact_and_basic_info")
                    : ((a = o + "?sk=about_work_and_education"),
                      o + "?sk=about_contact_and_basic_info")),
                (n = {
                  _shangjia_id: o
                    .replace("https://www.facebook.com/", "")
                    .replace("profile.php?id=", ""),
                  _shangjia_name: i,
                  _shangjia_jiaru_date: "",
                  _shangjia_work: $(this).find(".x1ok221b .x193iq5w").text(),
                  _shangjia_about_contact_and_basic_info_link: e,
                  _shangjia_about_work_and_education_link: a,
                  _shangjia_phone: "",
                  _shangjia_website: "",
                  _shangjia_email: "",
                  _shangjia_company_page_link: "",
                  _shangjia_company_is_request: 0,
                  _shangjia_company_name: "",
                  _shangjia_company_website: "",
                  _shangjia_company_phone: "",
                }),
                console.log("shangjia_search_people_caiji _shangjia_info"),
                console.log(n),
                s.push(n));
            }),
            0 < s.length) &&
            ((n = {
              action: "shangjia_items_update",
              info: "",
              shangjia_infos: s,
            }),
            console.log("message"),
            console.log(n),
            chrome.runtime.sendMessage(n, (n) => {
              console.log("答复", n), x("添加完成！");
            }))
          : x("请点击右上角插件图标，开启前台采集！");
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function _() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (n) => {
      console.log("can_list_caiji 答复", n);
      var e,
        n = JSON.parse(n);
      console.log(n.state),
        0 == n.state
          ? (n = window.location.href) &&
            -1 != n.indexOf("search/pages") &&
            (console.log("shangjia_search_pages_caiji"),
            (e = []),
            $(".x1xfsgkm .x1xwk8fm .x1yztbdb").each(function () {
              let n,
                i,
                o = $(this).find(".x1ja2u2z a.x1i10hfl").text(),
                a = $(this).find(".x1ja2u2z a.x1i10hfl").attr("href");
              a &&
                ((n = (a =
                  -1 == a.indexOf("profile")
                    ? a.split("?")[0]
                    : a.replace("&__tn__=%3C", ""))
                  .replace("https://www.facebook.com/", "")
                  .replace("profile.php?id=", "")
                  .replace("/", "")),
                $(this).find(".x1ok221b .x193iq5w").text(),
                (i = {
                  _shangjia_id: n,
                  _shangjia_company_name: o,
                  _shangjia_company_website: a,
                }),
                console.log("shangjia_search_pages_caiji _shangjia_info"),
                console.log(i),
                e.push(i));
            }),
            0 < e.length) &&
            ((n = {
              action: "shangjia_company_items_update",
              info: "",
              shangjia_infos: e,
            }),
            console.log("message"),
            console.log(n),
            chrome.runtime.sendMessage(n, (n) => {
              console.log("答复", n), x("添加完成！");
            }))
          : x("请点击右上角插件图标，开启前台采集！");
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function c() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (n) => {
      console.log("can_list_caiji 答复", n);
      var e,
        n = JSON.parse(n);
      console.log(n.state),
        0 == n.state
          ? (n = window.location.href) &&
            -1 != n.indexOf("search/places") &&
            (console.log("shangjia_search_places_caiji"),
            (e = []),
            $(".x1xfsgkm .x1xwk8fm .x1yztbdb").each(function () {
              let n,
                i,
                o = $(this).find(".x1ja2u2z a.x1i10hfl").text(),
                a = $(this).find(".x1ja2u2z a.x1i10hfl").attr("href");
              a &&
                ((n = (a =
                  -1 == a.indexOf("profile")
                    ? a.split("?")[0]
                    : a.replace("&__tn__=%3C", ""))
                  .replace("https://www.facebook.com/", "")
                  .replace("profile.php?id=", "")
                  .replace("/", "")),
                $(this).find(".x1ok221b .x193iq5w").text(),
                (i = {
                  _shangjia_id: n,
                  _shangjia_company_name: o,
                  _shangjia_company_website: a,
                }),
                e.push(i));
            }),
            0 < e.length) &&
            ((n = {
              action: "shangjia_company_items_update",
              info: "",
              shangjia_infos: e,
            }),
            console.log("message"),
            console.log(n),
            chrome.runtime.sendMessage(n, (n) => {
              console.log("答复", n), x("添加完成！");
            }))
          : x("请点击右上角插件图标，开启前台采集！");
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function l() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (n) => {
      console.log("can_list_caiji 答复", n);
      var s,
        n = JSON.parse(n);
      console.log(n.state),
        0 != n.state ||
          !(n = window.location.href) ||
          (-1 == n.indexOf("videos") && -1 == n.indexOf("watch")) ||
          (console.log("shangjia_video_like_people_caiji"),
          (s = []),
          $(".x78zum5 div[data-visualcompletion='ignore-dynamic']").each(
            function () {
              console.log("shangjia_video_like_people_caiji a1");
              let n,
                i = $(this).find(".x1rg5ohu a.x1i10hfl").text(),
                o = $(this).find(".x1rg5ohu a.x1i10hfl").attr("href"),
                a = "",
                e;
              o &&
                ((e =
                  -1 != o.indexOf("?")
                    ? ((a = o + "&sk=about_work_and_education"),
                      o + "&sk=about_contact_and_basic_info")
                    : ((a = o + "?sk=about_work_and_education"),
                      o + "?sk=about_contact_and_basic_info")),
                (n = {
                  _shangjia_id: o
                    .replace("https://www.facebook.com/", "")
                    .replace("profile.php?id=", ""),
                  _shangjia_name: i,
                  _shangjia_jiaru_date: "",
                  _shangjia_work: "",
                  _shangjia_about_contact_and_basic_info_link: e,
                  _shangjia_about_work_and_education_link: a,
                  _shangjia_phone: "",
                  _shangjia_website: "",
                  _shangjia_email: "",
                  _shangjia_company_page_link: "",
                  _shangjia_company_is_request: 0,
                  _shangjia_company_name: "",
                  _shangjia_company_website: "",
                  _shangjia_company_phone: "",
                }),
                console.log("shangjia_video_like_people_caiji _shangjia_info"),
                console.log(n),
                s.push(n)),
                500 == s.length &&
                  (f({
                    action: "shangjia_items_update",
                    info: "",
                    shangjia_infos: s,
                  }),
                  (s = []));
            }
          ),
          500 != s.length &&
            f({ action: "shangjia_items_update", info: "", shangjia_infos: s }));
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function h() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (n) => {
      console.log("can_list_caiji 答复", n);
      var s,
        n = JSON.parse(n);
      console.log(n.state),
        0 != n.state ||
          !(n = window.location.href) ||
          (-1 == n.indexOf("videos") && -1 == n.indexOf("watch")) ||
          (console.log("shangjia_video_comment_people_caiji"),
          (s = []),
          $(".x1jx94hy ul li").each(function () {
            console.log("shangjia_video_comment_people_caiji a1");
            let o,
              a = $(this).find(".x1y1aw1k .xt0psk2 a.x1i10hfl").text(),
              e = $(this).find(".x1y1aw1k .xt0psk2 a.x1i10hfl").attr("href");
            if (e) {
              let n = "",
                i;
              (e = (
                -1 != e.indexOf("profile.php") ? e.split("&") : e.split("?")
              )[0]) &&
                ((i =
                  -1 != e.indexOf("?")
                    ? ((n = e + "&sk=about_work_and_education"),
                      e + "&sk=about_contact_and_basic_info")
                    : ((n = e + "?sk=about_work_and_education"),
                      e + "?sk=about_contact_and_basic_info")),
                (o = {
                  _shangjia_id: e
                    .replace("https://www.facebook.com/", "")
                    .replace("profile.php?id=", ""),
                  _shangjia_name: a,
                  _shangjia_jiaru_date: "",
                  _shangjia_work: "",
                  _shangjia_about_contact_and_basic_info_link: i,
                  _shangjia_about_work_and_education_link: n,
                  _shangjia_phone: "",
                  _shangjia_website: "",
                  _shangjia_email: "",
                  _shangjia_company_page_link: "",
                  _shangjia_company_is_request: 0,
                  _shangjia_company_name: "",
                  _shangjia_company_website: "",
                  _shangjia_company_phone: "",
                }),
                console.log("shangjia_video_comment_people_caiji _shangjia_info"),
                console.log(o),
                s.push(o)),
                500 == s.length &&
                  (f({
                    action: "shangjia_items_update",
                    info: "",
                    shangjia_infos: s,
                  }),
                  (s = []));
            }
          }),
          500 != s.length &&
            f({ action: "shangjia_items_update", info: "", shangjia_infos: s }));
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function r() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (n) => {
      console.log("can_list_caiji 答复", n);
      n = JSON.parse(n);
      if ((console.log(n.state), 0 == n.state)) {
        n = window.location.href;
        if (n) {
          n.indexOf("posts");
          {
            console.log("shangjia_post_review_like_caiji");
            var t = [];
            let n = 1;
            $(".x1pi30zi .x1gslohp > div").each(function () {
              console.log("shangjia_post_review_like_caiji  _item a:" + n), n++;
              let o,
                a = $(this).find(".x1y1aw1k .xt0psk2 a.x1i10hfl").text(),
                e = $(this).find(".x1y1aw1k .xt0psk2 a.x1i10hfl").attr("href");
              if (e) {
                if (-1 != e.indexOf("/groups/")) {
                  console.log("_shangjia_profile_link"),
                    console.log(e),
                    -1 != e.indexOf("?") && ((s = e.split("?")), (e = s[0]));
                  var s = e.split("user/");
                  if (1 < s.length) {
                    let n = s[1];
                    (n = n.replace("/", "")),
                      console.log("_profile_id"),
                      console.log(n),
                      n && (e = "https://www.facebook.com/profile.php?id=" + n);
                  }
                }
                let n = "",
                  i;
                (e = (
                  -1 != e.indexOf("profile.php") ? e.split("&") : e.split("?")
                )[0]) &&
                  ((i =
                    -1 != e.indexOf("?")
                      ? ((n = e + "&sk=about_work_and_education"),
                        e + "&sk=about_contact_and_basic_info")
                      : ((n = e + "?sk=about_work_and_education"),
                        e + "?sk=about_contact_and_basic_info")),
                  (o = {
                    _shangjia_id: e
                      .replace("https://www.facebook.com/", "")
                      .replace("profile.php?id=", ""),
                    _shangjia_name: a,
                    _shangjia_jiaru_date: "",
                    _shangjia_work: "",
                    _shangjia_about_contact_and_basic_info_link: i,
                    _shangjia_about_work_and_education_link: n,
                    _shangjia_phone: "",
                    _shangjia_website: "",
                    _shangjia_email: "",
                    _shangjia_company_page_link: "",
                    _shangjia_company_is_request: 0,
                    _shangjia_company_name: "",
                    _shangjia_company_website: "",
                    _shangjia_company_phone: "",
                  }),
                  console.log(
                    "shangjia_video_comment_people_caiji _shangjia_info"
                  ),
                  console.log(o),
                  t.push(o)),
                  500 == t.length &&
                    (f({
                      action: "shangjia_items_update",
                      info: "",
                      shangjia_infos: t,
                    }),
                    (t = []));
              }
            }),
              (n = 1),
              $(".x78zum5 div[data-visualcompletion='ignore-dynamic']").each(
                function () {
                  console.log(
                    "shangjia_post_review_like_caiji like _item b:" + n
                  ),
                    n++;
                  let o = $(this).find(".x193iq5w .x1rg5ohu a.x1i10hfl").text(),
                    a = $(this)
                      .find(".x193iq5w .x1rg5ohu a.x1i10hfl")
                      .attr("href");
                  if (a) {
                    let n = "",
                      i;
                    if (
                      (a = (
                        -1 != a.indexOf("profile.php")
                          ? a.split("&")
                          : a.split("?")
                      )[0])
                    ) {
                      if (
                        (console.log("_shangjia_profile_link"),
                        console.log(a),
                        -1 != a.indexOf("/groups/"))
                      ) {
                        console.log("_shangjia_profile_link b"),
                          console.log(a),
                          -1 != a.indexOf("?") &&
                            ((e = a.split("?")), (a = e[0]));
                        var e = a.split("user/");
                        if (1 < e.length) {
                          let n = e[1];
                          (n = n.replace("/", "")),
                            console.log("_profile_id"),
                            console.log(n),
                            n &&
                              (a =
                                "https://www.facebook.com/profile.php?id=" + n);
                        }
                      }
                      i =
                        -1 != a.indexOf("?")
                          ? ((n = a + "&sk=about_work_and_education"),
                            a + "&sk=about_contact_and_basic_info")
                          : ((n = a + "?sk=about_work_and_education"),
                            a + "?sk=about_contact_and_basic_info");
                      e = {
                        _shangjia_id: a
                          .replace("https://www.facebook.com/", "")
                          .replace("profile.php?id=", ""),
                        _shangjia_name: o,
                        _shangjia_jiaru_date: "",
                        _shangjia_work: "",
                        _shangjia_about_contact_and_basic_info_link: i,
                        _shangjia_about_work_and_education_link: n,
                        _shangjia_phone: "",
                        _shangjia_website: "",
                        _shangjia_email: "",
                        _shangjia_company_page_link: "",
                        _shangjia_company_is_request: 0,
                        _shangjia_company_name: "",
                        _shangjia_company_website: "",
                        _shangjia_company_phone: "",
                      };
                      console.log(
                        "shangjia_video_comment_people_caiji like _shangjia_info"
                      ),
                        console.log(e),
                        t.push(e);
                    }
                    500 == t.length &&
                      (f({
                        action: "shangjia_items_update",
                        info: "",
                        shangjia_infos: t,
                      }),
                      (t = []));
                  }
                }
              ),
              500 != t.length &&
                f({
                  action: "shangjia_items_update",
                  info: "",
                  shangjia_infos: t,
                });
          }
        }
      }
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function n() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ action: "can_list_caiji", info: "" }, (n) => {
      console.log("can_list_caiji 答复", n);
      var e,
        n = JSON.parse(n),
        n = (console.log(n.state), n.state, window.location.href);
      n &&
        -1 != n.indexOf("search/posts") &&
        (console.log("shangjia_search_posts_caiji"),
        (e = []),
        $(".x1xfsgkm .x1xwk8fm .x1yztbdb").each(function () {
          let n,
            i,
            o = $(this).find(".x1ja2u2z a.x1i10hfl").text(),
            a = $(this).find(".x1ja2u2z a.x1i10hfl").attr("href");
          a &&
            ((n = (a =
              -1 == a.indexOf("profile")
                ? a.split("?")[0]
                : a.replace("&__tn__=%3C", ""))
              .replace("https://www.facebook.com/", "")
              .replace("profile.php?id=", "")
              .replace("/", "")),
            $(this).find(".x1ok221b .x193iq5w").text(),
            (i = {
              _shangjia_id: n,
              _shangjia_company_name: o,
              _shangjia_company_website: a,
            }),
            console.log("shangjia_search_pages_caiji _shangjia_info"),
            console.log(i),
            e.push(i));
        }),
        0 < e.length) &&
        ((n = {
          action: "shangjia_company_items_update",
          info: "",
          shangjia_infos: e,
        }),
        console.log("message"),
        console.log(n),
        chrome.runtime.sendMessage(n, (n) => {
          console.log("答复", n), x("添加完成！");
        }));
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
var g = "";
function p(n, o) {
  for (
    performanceResourceList = n.getEntriesByType("resource"), i = 0;
    i < performanceResourceList.length;
    i++
  )
    "xmlhttprequest" ==
      (performanceResourceItem = performanceResourceList[i]).initiatorType &&
      -1 != performanceResourceItem.name.indexOf("graphql") &&
      (console.log("bbbb" + performanceResourceItem.name),
      setTimeout(function () {
        m(), l(), h(), r();
      }, 2e3));
}
var d = new PerformanceObserver(p);
function f(n = {}) {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    console.log("message"),
    console.log(n),
    chrome.runtime.sendMessage(n, (n) => {
      console.log("答复", n);
    });
  } else {
    console.error('chrome.runtime is not available');
  }
}
function u(n, o) {
  var a = XLSX.utils.book_new(),
    n = XLSX.utils.json_to_sheet(n);
  XLSX.utils.book_append_sheet(a, n, o), XLSX.writeFile(a, i + ".xlsx");
}
function j() {
  var a = [];
  $("div[role='list'] div[role='listitem']").each(function () {
    console.log("listitem");
    var n,
      i = $(this).find("a[role='link']:eq(1)").text(),
      o = $(this).find("a[role='link']:eq(1)").attr("href");
    o &&
      ((n = (n = (o = "https://www.facebook.com" + o).split("/"))[
        n.length - 2
      ]),
      a.push({
        _shangjia_id: n,
        _shangjia_name: i,
        _shangjia_profile_link: "https://www.facebook.com/profile.php?id=" + n,
        _shangjia_group_link: o,
      }));
  }),
    u(a, "group-members-links-export-" + Date.now(), "Sheet1");
}
function x(n = "", i = !0) {
  $(".div_js_msg").remove();
  n = $("<div>", {
    text: n,
    class: "div_js_msg",
    style:
      "display: block;\n    position: fixed;\n    bottom: 10px;\n    right:30px;\n    z-index: 999;\n    background: #019bfb;\n    width: auto;\n    height: 30px;\n    line-height: 30px;\n    padding: 10px 15px;\n    color: #FFF;\n    font-weight: bold;\n    cursor:pointer;\n    border: 0;\n",
    click: function () {},
  });
  $("body").append(n),
    i &&
      setTimeout(function () {
        $(".div_js_msg").remove();
      }, 3e3);
}
function m() {
  console.log("add_export_pingtai_btn");
  var n,
    i = window.location.href;
  console.log("current_url:" + i),
    $(".pagesAddtoPluginButton").remove(),
    $(".placesAddtoPluginButton").remove(),
    $(".peopleAddtoPluginButton").remove(),
    $(".groupAddtoPluginButton").remove(),
    $(".groupExportButton").remove(),
    $(".friendsAddtoPluginButton").remove(),
    $(".postsAddtoPluginButton").remove(),
    -1 != i.indexOf("groups") && -1 != i.indexOf("members")
      ? (console.log("add_export_pingtai_btn a1"),
        (n = $("<button>", {
          text: "导出群组成员ID及链接",
          class: "groupExportButton",
          style:
            "display: block;\n    position: fixed;\n    bottom: 140px;\n    right:30px;\n    z-index: 999;\n    background: #fb7701;\n    width: 180px;\n    height: 46px;\n    line-height: 46px;\n    color: #FFF;\n    font-weight: bold;\n    cursor:pointer;\n    border: 0;\n    border-radius: 22px;",
          click: function () {
            j();
          },
        })),
        $("body").append(n),
        (n = $("<button>", {
          text: "批量加入到插件",
          class: "groupAddtoPluginButton",
          style:
            "display: block;\n    position: fixed;\n    bottom: 80px;\n    right:30px;\n    z-index: 999;\n    background: #fb7701;\n    width: 180px;\n    height: 46px;\n    line-height: 46px;\n    color: #FFF;\n    font-weight: bold;\n    cursor:pointer;\n    border: 0;\n    border-radius: 22px;",
          click: function () {
            x("加入需要花费些时间，稍等...", !1), o(), a();
          },
        })),
        $("body").append(n))
      : -1 != i.indexOf("search/pages")
      ? ((n = $("<button>", {
          text: "批量加入到插件",
          class: "pagesAddtoPluginButton",
          style:
            "display: block;\n    position: fixed;\n    bottom: 80px;\n    right:30px;\n    z-index: 999;\n    background: #fb7701;\n    width: 180px;\n    height: 46px;\n    line-height: 46px;\n    color: #FFF;\n    font-weight: bold;\n    cursor:pointer;\n    border: 0;\n    border-radius: 22px;",
          click: function () {
            x("加入需要花费些时间，稍等...", !1), _();
          },
        })),
        $("body").append(n))
      : -1 != i.indexOf("search/places")
      ? ((n = $("<button>", {
          text: "批量加入到插件",
          class: "placesAddtoPluginButton",
          style:
            "display: block;\n    position: fixed;\n    bottom: 80px;\n    right:30px;\n    z-index: 999;\n    background: #fb7701;\n    width: 180px;\n    height: 46px;\n    line-height: 46px;\n    color: #FFF;\n    font-weight: bold;\n    cursor:pointer;\n    border: 0;\n    border-radius: 22px;",
          click: function () {
            x("加入需要花费些时间，稍等...", !1), c();
          },
        })),
        $("body").append(n))
      : -1 != i.indexOf("search/people")
      ? ((n = $("<button>", {
          text: "批量加入到插件",
          class: "peopleAddtoPluginButton",
          style:
            "display: block;\n    position: fixed;\n    bottom: 80px;\n    right:30px;\n    z-index: 999;\n    background: #fb7701;\n    width: 180px;\n    height: 46px;\n    line-height: 46px;\n    color: #FFF;\n    font-weight: bold;\n    cursor:pointer;\n    border: 0;\n    border-radius: 22px;",
          click: function () {
            x("加入需要花费些时间，稍等...", !1), t();
          },
        })),
        $("body").append(n))
      : -1 != i.indexOf("search/posts") ||
        ((n = $(
          "a[href*='sk=followers'],a[href*='sk=friends'],a[href*='sk=following'],a[href*='sk=friends_likes'],a[href*='/friends']"
        ).attr("href")),
        console.log("shangjia_friends_caiji button href"),
        console.log("_url dd:" + n),
        !n) ||
        -1 != i.indexOf("groups") ||
        -1 != i.indexOf("members") ||
        -1 != i.indexOf("search/pages") ||
        (-1 == n.indexOf("friends") &&
          -1 == n.indexOf("followers") &&
          -1 == n.indexOf("following") &&
          -1 == n.indexOf("friends_likes")) ||
        (console.log("shangjia_friends_caiji afaf"),
        (i = $("<button>", {
          text: "批量加入到插件",
          class: "friendsAddtoPluginButton",
          style:
            "display: block;\n    position: fixed;\n    bottom: 80px;\n    right:30px;\n    z-index: 999;\n    background: #fb7701;\n    width: 180px;\n    height: 46px;\n    line-height: 46px;\n    color: #FFF;\n    font-weight: bold;\n    cursor:pointer;\n    border: 0;\n    border-radius: 22px;",
          click: function () {
            x("加入需要花费些时间，稍等...", !1), e(), s();
          },
        })),
        $("body").append(i));
}
d.observe({ entryTypes: ["resource", "navigation", "paint"] }),
  $(document).ready(function () {
    setTimeout(function () {
      m();
    }, 2e3);
    
  });
